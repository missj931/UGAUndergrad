
/**
 * .TestAssignmentB.
 * 
 * @author Dr. Janine E. Aronson 
 * @version 20140105
 */
public class TestAssignmentB
{

    private Picture assignmentB;
    
    /**
     * Constructor for objects of class TestAssignmentB
     */
    public TestAssignmentB()
    {
        assignmentB = new Picture();
        assignmentB.draw();
        assignmentB.eveningVisitor();
    }

}
