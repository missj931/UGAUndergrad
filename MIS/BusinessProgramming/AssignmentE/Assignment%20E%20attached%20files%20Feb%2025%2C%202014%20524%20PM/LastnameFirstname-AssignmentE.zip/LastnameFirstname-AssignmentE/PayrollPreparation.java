/**
 * 
 * Name:
 * Code comment:
 * 
 * 
 * 
 * 
 * .PayrollPreparation. Assignment E. 
 * 
 * @author Dr. Janine E. Aronson 
 * @version 20140123
 * 
 * Your work involves reading in a file, working with the data and printing out
 *   relevant output. Do your work in method printEmployeeData.
 * 
 */
public class PayrollPreparation
{

    /**
     * Constructor for objects of class PayrollPreparation
     */
    public PayrollPreparation()
    {
        // No instance variables.
        
    }

    /**
     * .printEmployeeData. All work is to be done here.
     *    There are no fields (instance variables/attributes/global variables).
     * 
     * Read the data line by line and print out the relevant data with computations.
     * 
     * Dr. Janine E. Aronson Solution to Assignment E:
     */
    public void printEmployeeData()
    {
 
        // define a new (local) ReadFile object and connect it up to the payroll.txt file.
        ReadFile reader;
        // Store it as "reader" create a new Readfile object and connect it up to the payroll.txt file.
        // Carry on from there, following the instructions in the assignment.
        
    }
}
