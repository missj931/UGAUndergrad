/**
 *.TesterAssignmentE01.
 * 
 * @author Dr. Janine E. Aronson 
 * @version 20140123
 */
public class TesterAssignmentE01
{
    // instance variables
    PayrollPreparation x;

    /**
     * Constructor
     */
    public TesterAssignmentE01()
    {
        x = new PayrollPreparation();
        x.printEmployeeData();
    }
}
